'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { useAuthStore } from '../../store/useAuthStore';
import { useVaultStore, EncryptedVaultEntry } from '../../store/useVaultStore';
import { api, getApiBaseUrl } from '../../lib/api/client';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';

// Phase 3 Modular Vault Component Imports
import { SessionLock } from '../../components/vault/SessionLock';
import { PasswordModal } from '../../components/vault/PasswordModal';
import { VaultSearch } from '../../components/vault/VaultSearch';
import { VaultTable } from '../../components/vault/VaultTable';
import { VaultCard } from '../../components/vault/VaultCard';

// The Obsidian Sanctuary Security Additions
import { ClipboardPurgeBar } from '../../components/vault/ClipboardPurgeBar';
import { TamperAlarm } from '../../components/vault/TamperAlarm';
import { SanctuaryGate } from '../../components/vault/SanctuaryGate';
import { ExtensionStatusBadge } from '../../components/vault/ExtensionStatusBadge';

import { 
  Shield, 
  Plus, 
  Database, 
  Power, 
  CheckCircle2, 
  Lock, 
  Unlock, 
  RefreshCw,
  Search,
  LockKeyhole,
  Flower2
} from 'lucide-react';

/**
 * Premium Zero-Knowledge Vault Dashboard.
 * Integrates inactivity autolocking, debounced search filters,
 * unified Add/Edit modal dialogs, secure clipboards, and responsive grids.
 */
export default function DashboardPage() {
  const router = useRouter();
  
  // Auth Store Session states
  const { address, isAuthenticated, clearSession } = useAuthStore();
  
  // Vault Store Cryptographic states
  const { 
    isUnlocked, 
    vaultEntries, 
    searchQuery,
    isLoading: vaultLoading, 
    error: vaultError,
    lockVault, 
    fetchEntries
  } = useVaultStore();

  // Local UX state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [entryToEdit, setEntryToEdit] = useState<EncryptedVaultEntry & { decryptedPassword?: string } | null>(null);

  // Dev Session diagnostics state
  const [profile, setProfile] = useState<any>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  const [apiLoading, setApiLoading] = useState(true);

  // Authentication Route Guardian
  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, router]);

  // Query Backend Protected Route to Verify JWT Signature integrity on mount
  useEffect(() => {
    if (!isAuthenticated) return;

    const fetchProfile = async () => {
      try {
        setApiLoading(true);
        setApiError(null);
        const data = await api.get('/auth/profile');
        setProfile(data.user);
      } catch (err: any) {
        console.error('Failed to verify JWT authorization status:', err);
        setApiError(err.message || 'API verification failed. Secure session has expired.');
      } finally {
        setApiLoading(false);
      }
    };

    fetchProfile();
  }, [isAuthenticated]);

  // Extension Session Synchronization
  // Writes session data to a hidden DOM element that the content script reads.
  // Works even when token is null (cookie-based auth) by fetching a fresh token.
  const { token } = useAuthStore();
  const { derivationSignature, extensionKeyMaterial } = useVaultStore();

  useEffect(() => {
    if (!address) return;

    const syncToExtension = async () => {
      // Get a fresh token if we don't have one in memory (cookie-based session)
      let activeToken = token;
      if (!activeToken) {
        try {
          const data = await fetch(`${getApiBaseUrl()}/auth/refresh`, {
            method: 'POST',
            credentials: 'include',
          }).then(r => r.json());
          activeToken = data.token || null;
        } catch {
          // Can't get token, skip sync
          return;
        }
      }
      if (!activeToken) return;

      console.log(
        '[Sphynx Debug] Sync Attempt',
        {
          hasKeyMaterial: !!extensionKeyMaterial,
          keyLength: extensionKeyMaterial?.length
        }
      );

      const keyMaterial = extensionKeyMaterial;
      console.log(
        '[Sphynx Debug] Sync Payload',
        {
          address,
          token: activeToken,
          hasKeyMaterial: !!keyMaterial,
          keyMaterialLength: keyMaterial?.length
        }
      );

      const payload = {
        address,
        derivationSignature: derivationSignature || '',
        token: activeToken,
        keyMaterial: extensionKeyMaterial || '',
      };

      // Write to a hidden DOM element the content script can read
      let syncEl = document.getElementById('__sphynx_sync__');
      if (!syncEl) {
        syncEl = document.createElement('div');
        syncEl.id = '__sphynx_sync__';
        syncEl.style.display = 'none';
        document.body.appendChild(syncEl);
      }
      syncEl.setAttribute('data-session', JSON.stringify(payload));

      // Also post message
      window.postMessage({ type: 'SPHYNX_SYNC_SESSION', payload }, '*');
      document.dispatchEvent(new CustomEvent('sphynx-sync-session', { detail: payload }));

      console.log('[Sphynx Sync] Session synced to extension', { hasKeyMaterial: !!extensionKeyMaterial, hasToken: !!activeToken });
    };

    // Sync immediately and every 3 seconds
    syncToExtension();
    const interval = setInterval(syncToExtension, 3000);

    // Listen for confirmation
    const handleConfirm = (event: MessageEvent) => {
      if (event.data?.type === 'SPHYNX_SYNC_COMPLETE') {
        console.log('[Sphynx Sync] Extension confirmed receipt');
        clearInterval(interval);
      }
    };
    window.addEventListener('message', handleConfirm);

    return () => {
      clearInterval(interval);
      window.removeEventListener('message', handleConfirm);
    };
  }, [address, token, derivationSignature, extensionKeyMaterial]);

  // Trigger atomic logout
  const handleLogout = () => {
    lockVault();
    clearSession();
    router.push('/login');
  };

  // Opens Edit modal pre-filled with plaintext credentials
  const handleEditClick = (entry: EncryptedVaultEntry & { decryptedPassword?: string }) => {
    setEntryToEdit(entry);
    setIsModalOpen(true);
  };

  if (!isAuthenticated) {
    return null; // Suppress client-side content flashes
  }

  // --- LOCAL DEBOUNCED / SEARCH FILTERING ---
  // Filters ZK vault entries locally based on label or username search inputs
  const filteredEntries = vaultEntries.filter((entry) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
    
    return (
      entry.label.toLowerCase().includes(query) ||
      (entry.username && entry.username.toLowerCase().includes(query))
    );
  });

  // --- RENDERING ROUTE 1: Sanctuary Gate (new user onboarding + returning user unlock) ---
  if (!isUnlocked) {
    return <SanctuaryGate onLogout={handleLogout} />;
  }

  // --- RENDERING ROUTE 2: Vault Unlocked Workspace ---
  return (
    <div className="min-h-screen bg-[#0A1020] text-slate-100 pb-20 relative">
      
      {/* Depleting progress bar countdown at the very top of the screen */}
      <ClipboardPurgeBar />

      {/* Pulsing red perimeter overlay for tamper alarm states */}
      <TamperAlarm />

      {/* Background inactivity monitoring trigger */}
      <SessionLock />

      {vaultError && (
        <div className="mx-auto max-w-7xl px-6 pt-4 sm:px-8">
          <div className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-300">
            {vaultError}
          </div>
        </div>
      )}

      {/* Unified password creation/edit modal */}
      <PasswordModal 
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEntryToEdit(null);
        }}
        entryToEdit={entryToEdit}
      />
      
      {/* Radial ambient background glows */}
      <div className="absolute top-0 right-0 -z-10 h-[500px] w-[500px] rounded-full bg-[#79E6FF]/3 blur-[120px] animate-pulse-glow" />
      <div className="absolute bottom-0 left-0 -z-10 h-[500px] w-[500px] rounded-full bg-emerald-500/1 blur-[120px] animate-pulse-glow" style={{ animationDelay: '2s' }} />

      {/* Unlocked Header */}
      <header className="border-b border-white/5 bg-[#0A1020]/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 sm:px-8">
          <div className="flex items-center">
            <Image
              src="/Logo-with-password.png"
              alt="Sphynx Logo"
              width={280}
              height={130}
              style={{ width: 'auto', height: '130px' }}
              className="object-contain drop-shadow-[0_0_12px_rgba(212,175,55,0.25)] transition-transform duration-300 hover:scale-105"
              priority
            />
          </div>

          <div className="flex items-center gap-3.5">
            <ExtensionStatusBadge />
            <div className="hidden md:flex items-center gap-2 rounded-xl border border-emerald-500/20 bg-emerald-500/5 px-3 py-1.5 text-xs font-mono text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.05)] select-none">
              <Unlock size={12} className="animate-pulse" />
              Integrity Verified
            </div>
            
            <Button
              variant="outline"
              onClick={lockVault}
              className="px-4 py-2 border-[#79E6FF]/25 hover:border-[#79E6FF]/60 text-[#79E6FF] hover:text-white text-xs font-bold gap-1.5 shadow-[inset_0_0_10px_rgba(212,175,55,0.05)]"
            >
              <Lock size={13} />
              Lock Vault
            </Button>
            
            <Button
              variant="outline"
              onClick={handleLogout}
              className="px-4 py-2 border-white/10 hover:border-red-500/20 text-white/50 hover:text-red-400 text-xs font-semibold gap-1.5"
            >
              <Power size={13} />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Unlocked Dashboard container */}
      <main className="mx-auto max-w-7xl px-6 pt-12 sm:px-8 animate-fade-in">
        
        {/* Workspace Title bar & CTAs */}
        <div className="mb-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">Your security workspace</h1>
            <p className="mt-1.5 text-sm text-slate-400">
              Private by design. Built for control.
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <Link href="/guardians">
              <Button 
                variant="outline" 
                className="gap-1.5 text-xs font-bold px-5 py-3 border-white/10 hover:border-[#79E6FF]/30 text-white/60 hover:text-[#79E6FF]"
              >
                <Shield size={14} />
                Guardians
              </Button>
            </Link>

            <Link href="/audit">
              <Button 
                variant="outline" 
                className="gap-1.5 text-xs font-bold px-5 py-3 border-[#79E6FF]/20 hover:border-[#79E6FF]/50 text-[#79E6FF] hover:text-white"
              >
                <Flower2 size={14} />
                Security Garden
              </Button>
            </Link>
            
            <Button 
              variant="primary" 
              onClick={() => {
                setEntryToEdit(null);
                setIsModalOpen(true);
              }} 
              className="gap-1.5 text-xs font-bold px-6 py-3"
            >
              <Plus size={14} />
              Add credential
            </Button>
          </div>
        </div>

        {/* Dashboard Workspace */}
        <div className="grid gap-8 lg:grid-cols-4">
          
          {/* Diagnostic status block (Left Panel - Span 1) */}
          <div className="lg:col-span-1 flex flex-col gap-6">
            <Card className="border-[#79E6FF]/10 bg-[#0A1020]/50 text-xs p-5 shadow-[0_8px_32px_rgba(0,0,0,0.37)]">
              <h2 className="text-sm font-bold mb-4 flex items-center gap-2 text-[#79E6FF]">
                <Database size={15} />
                Session Diagnostics
              </h2>

              <div className="flex flex-col gap-4">
                <div>
                  <span className="text-[10px] text-white/30 uppercase tracking-wider block mb-0.5 font-semibold">derived K_vault status</span>
                  <span className="font-mono text-emerald-400 flex items-center gap-1.5 py-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    AES-GCM Memory Lock
                  </span>
                </div>

                <div>
                  <span className="text-[10px] text-white/30 uppercase tracking-wider block mb-0.5 font-semibold font-mono">express JWT handshake</span>
                  {apiLoading ? (
                    <span className="text-slate-400 animate-pulse font-mono">Verifying...</span>
                  ) : apiError ? (
                    <span className="text-red-400 flex items-center gap-1 font-mono">{apiError}</span>
                  ) : (
                    <span className="text-emerald-400 flex items-center gap-1 font-mono"><CheckCircle2 size={11} /> Handshake Verified</span>
                  )}
                </div>

                <div>
                  <span className="text-[10px] text-white/30 uppercase tracking-wider block mb-0.5 font-semibold">Session Isolation</span>
                  <span className="font-mono text-[10px] text-[#79E6FF] bg-amber-950/15 border border-[#79E6FF]/15 rounded-xl px-2.5 py-2.5 block select-none mt-1 leading-relaxed">
                    🔒 Non-Extractable CryptoKey
                  </span>
                  <span className="text-[9.5px] text-white/30 mt-2 block select-none leading-relaxed">
                    The derived keys use <code>extractable: false</code>. It is physically impossible for client scripts (XSS) to harvest or read the keys.
                  </span>
                </div>
              </div>
            </Card>

            {/* Note banner */}
            <div className="rounded-2xl border border-[#79E6FF]/10 bg-amber-950/5 p-4 text-xs leading-relaxed text-slate-400">
              <div className="font-bold flex items-center gap-1.5 mb-1.5 text-[#79E6FF]">
                <Shield size={14} className="shrink-0" />
                Zero-Trust Philosophy
              </div>
              Your master key is expanded via HKDF using deterministic signatures. Secrets are decrypted strictly inside browser memory sandbox.
            </div>
          </div>

          {/* Secure Locker workspace (Right Panel - Span 3) */}
          <div className="lg:col-span-3 flex flex-col gap-6">
            
            {/* Search and Filters Bar */}
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <VaultSearch />
              
              <button
                onClick={fetchEntries}
                className="text-xs text-[#79E6FF]/70 hover:text-white transition-colors flex items-center gap-1.5 font-semibold border border-[#79E6FF]/15 bg-white/[0.01] hover:bg-[#79E6FF]/5 rounded-2xl px-4 py-2.5 z-10"
              >
                <RefreshCw size={12} className={vaultLoading ? "animate-spin" : ""} />
                Sync vault
              </button>
            </div>

            {/* Vault List UI */}
            <Card className="bg-[#0A1020]/20 border-white/5 flex flex-col p-6 min-h-[400px] shadow-[0_8px_32px_rgba(0,0,0,0.37)]">
              {vaultEntries.length === 0 ? (
                /* Empty state UI */
                <div className="flex flex-col items-center justify-center py-24 my-auto">
                  <LockKeyhole className="h-10 w-10 text-white/10 mb-4" />
                  <p className="text-sm font-semibold text-slate-400">Your vault is ready</p>
                  <p className="text-xs text-white/20 mt-1 max-w-xs text-center leading-relaxed">
                    Local browser GCM encryptions are active. Click the "Add credential" button to add your first secure record.
                  </p>
                </div>
              ) : filteredEntries.length === 0 ? (
                /* Search empty state */
                <div className="flex flex-col items-center justify-center py-24 my-auto">
                  <Search className="h-10 w-10 text-white/10 mb-4 animate-pulse" />
                  <p className="text-sm font-semibold text-slate-400">No matching secrets found</p>
                  <p className="text-xs text-white/20 mt-1 max-w-xs text-center leading-relaxed">
                    We couldn't find any credentials matching "{searchQuery}". Check the query or clear the filter.
                  </p>
                </div>
              ) : (
                <div className="flex flex-col gap-6">
                  {/* Desktop view: Vault Table (hidden on mobile, shown on md+) */}
                  <div className="hidden md:block">
                    <VaultTable 
                      entries={filteredEntries} 
                      onEditClick={handleEditClick} 
                    />
                  </div>

                  {/* Mobile view: Vault Cards Grid (shown on mobile, hidden on md+) */}
                  <div className="block md:hidden">
                    <div className="grid grid-cols-1 gap-5">
                      {filteredEntries.map((entry) => (
                        <VaultCard 
                          key={entry.id} 
                          entry={entry} 
                          onEditClick={handleEditClick} 
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </Card>

          </div>

        </div>

      </main>
    </div>
  );
}
